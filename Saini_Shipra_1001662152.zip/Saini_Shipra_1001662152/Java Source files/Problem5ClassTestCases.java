package Homework5;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)

public class Problem5ClassTestCases {
	
private Problem5Class prob5;
	
    @Before
	public void setUp() throws Exception {
    	prob5 = new Problem5Class();
    }
    
    @Test
    @FileParameters("src/Homework5/Problem5TestCaseTable.csv")
    
    public void test(int testcaseNumber, double cart, boolean coupon, int memberpoints, int items, boolean member, double taxrate,
    double result, String basisPath, String mcdc )
    {
    assertEquals(result, prob5.determineTotal(cart, member, items, coupon, memberpoints, taxrate), 0.006);

    }

}
