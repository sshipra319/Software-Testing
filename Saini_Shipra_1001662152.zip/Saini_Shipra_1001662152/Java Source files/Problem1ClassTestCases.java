package Homework5;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import Homework5.Problem1Class;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class Problem1ClassTestCases {
	
	private Problem1Class prob1;
	
    @Before
	public void setUp() throws Exception {
    	prob1 = new Problem1Class();
    }
    
    @Test
    @FileParameters("src/Homework5/Problem1TestCaseTable.csv")
    
    public void test(int testcaseNumber, double cart, boolean coupon, int memberpoints, int items, boolean member, double taxrate,
    double result, String basisPath, String mcdc )
    {
    assertEquals(result, prob1.determineTotal(cart, member, items, coupon, memberpoints, taxrate), 0.006);

    }


}
