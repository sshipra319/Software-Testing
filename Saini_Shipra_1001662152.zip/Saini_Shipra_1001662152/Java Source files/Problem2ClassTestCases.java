package Homework5;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class Problem2ClassTestCases {
	
private Problem2Class prob2;
	
    @Before
	public void setUp() throws Exception {
    	prob2 = new Problem2Class();
    }
    
    @Test
    @FileParameters("src/Homework5/Problem2TestCaseTable.csv")
    
    public void test(int testcaseNumber, double distance, double speed, boolean cruiseEngaged, boolean applyBrake,
    		double brakingFactor, String basisPath, String mcdc )
    {
    prob2.autoBraking(distance, speed, cruiseEngaged);
    prob2.setBrakingFactor(brakingFactor);
    prob2.setApplyBrakes(applyBrake);
	assertEquals(applyBrake,prob2.isApplyBrakes());

    }

}