package Homework3;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class Problem4ClassTestCases {
Problem4Class prb4;
	
	@Before
	public void setUp () throws Exception {
		prb4 = new Problem4Class();
	}
	
	@FileParameters("src/Homework3/Problem4TestCaseTable.csv")
	@Test
	public void test(int testcasenum, boolean landing, double speed, double altitude, 
			Problem4Class.landing action, String basisPath, String mcdc) {
		
		prb4.landCraft(landing, altitude, speed);
		assertEquals(action,prb4.getAction());
	}

}
