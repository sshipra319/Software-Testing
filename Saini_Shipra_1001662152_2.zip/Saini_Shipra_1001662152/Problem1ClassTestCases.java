package Homework3;
import static junitparams.JUnitParamsRunner.$;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;

@RunWith(JUnitParamsRunner.class)
public class Problem1ClassTestCases {
	
private Problem1Class prob1JUnit;	
	@SuppressWarnings("unused")
	private static final Object[] parametersForProblem1ClassTestCases () {
		return $(
				
//		Parameters are: (1,2,3,4,5,6)
//		1 = batteryPower, 2 = expRed, 3 = expYellow, 4 = expGreen, 5 = expBell, 6 = expSiren
				
//				Test case 1
				$(0, false, false, false, false, true),
//				Test case 2
				$(49.9, false, false, false, true, false),
//				Test case 3
				$(75, true, false, false, false, false),
//				Test case 4
				$(124.9, true, true, false, false, false),
//				Test case 5
				$(250, false, true, false, false, false),
//				Test case 6
				$(250.1, false, false, true, false, false),
//				Test case 7
				$(0.1, false, false, false, true, false),
//				Test case 8
				$(50, true, false, false, false, false),
//				Test case 9
				$(75.1, true, true, false, false, false),
//				Test case 10
				$(125, false, true, false, false, false),
//				Test case 11
				$(1000, false, false, true, false, false)
		);
	}
	
	@Before
	public void setUp () {
		prob1JUnit = new Problem1Class();
	}
	
	@Test
	@Parameters(method="parametersForProblem1ClassTestCases")
	public void test(double batteryPower, boolean expRed, boolean expYellow, boolean expGreen, boolean expBell, boolean expSiren) {
		
		prob1JUnit.calcLights(batteryPower);
		assertEquals(expRed,prob1JUnit.isRedLight());
		assertEquals(expYellow,prob1JUnit.isYellowLight());
		assertEquals(expGreen,prob1JUnit.isGreenLight());
		assertEquals(expBell,prob1JUnit.isBell());
		assertEquals(expSiren,prob1JUnit.isSiren());
	}

}
