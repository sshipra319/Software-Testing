package Homework3;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class Problem3ClassTestCases {
	Problem3Class prb3;
	
	@Before
	public void setUp () throws Exception {
		prb3 = new Problem3Class();
	}
	
	@FileParameters("src/Homework3/Problem3TestCaseTable.csv")
	@Test
	public void test(int testcasenum, double distance, boolean cruiseRequested, double speed, boolean redLight, boolean yellowLight, boolean greenLight, boolean caution, 
			boolean warning, boolean cruiseEngaged, String basisPath, String mcdc	) {
		
		prb3.setWarnings(cruiseRequested, distance, speed);
		assertEquals(redLight,prb3.isRedLight());
		assertEquals(yellowLight,prb3.isYellowLight());
		assertEquals(greenLight,prb3.isGreenLight());
		assertEquals(caution,prb3.isCaution());
		assertEquals(warning,prb3.isWarning());
		assertEquals(cruiseEngaged,prb3.isCruiseEngaged());
	}


}
